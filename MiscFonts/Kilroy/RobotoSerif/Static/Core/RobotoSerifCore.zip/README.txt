This is a version of Roboto Serif for legacy word processors.
These are the exact same files as distributed by Google in the
static renderings of Roboto Serif fonts; the only change is that
the number of files are reduced to work with the traditional
regular/bold/italic/bold+italic format word processors like to
use.

This way, one can edit a document on one’s home computer and 
upload it to Google Docs with the same font, without needing 
to upload a font or without needing to include the font with
the document.