This is a slight conversion of the older version of Cousine with
delta hinting (because, yes, low resolutions displays are still sometimes
a thing.  Even here in the 2020s) to have the left quotes in the normal
(i.e. neither bold nor italic) font be more distinct from the right 
quotes.

I have also added card symbols from the public domain part of DejaVU to
the normal mono font.
